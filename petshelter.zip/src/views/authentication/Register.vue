<template>
    <div>
        <h1>Register Route</h1>
        <form class="custom-form" v-on:submit.prevent="onSubmit">
            <div class="form-group">
                <label for="first">First Name</label>
                <input v-model="first" type="text" class="form-control" 
                id="first" placeholder="First name" required/>
            </div>
                <div class="form-group">
                <label for="last">Last Name</label>
                <input v-model="last" type="text" class="form-control" 
                id="last" placeholder="Last Name" required/>
            </div>
                <div class="form-group">
                <label for="username">Username</label>
                <input v-model="username" type="text" class="form-control" 
                id="username" placeholder="username" required/>
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input v-model="password" type="password" class="form-control" 
                id="password" placeholder="password" required/>
            </div>
            <div class="form-group">
            <button type="submit" class="btn btn-secondary">Register</button>
            </div>
        </form>
    </div>
    
</template>

<script>
    import * as auth from '../../services/AuthService'

    export default {
        name:'register',
        data: function(){
            return{
                username:'',
                password: '',
                first: '',
                last:''            
            }
        },
        methods: {
            onSubmit: async function(){
                const user = {
                    username: this.username,
                    password: this.password,
                    first: this.first,
                    last: this.last
                }
                const registerPromise = auth.registerUser(user);
                const loginPromise = auth.login(user);
                console.log("HERE");
                await Promise.all([registerPromise, loginPromise]);
                this.$router.push("/");
            }
        }
    }
</script>