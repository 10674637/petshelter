<template>
    <div class="jumbotron custom-bg-dark">
        <img src="../../assets/AdoptionCenter.jpg" class="card-img-top" alt="...">
        <br>
        <h1 class="display-4">Contact Information</h1>
        <hr class="my-4">
        <h3>
        Meet with the animals only by Appointment due to Covid-19.
        </h3>

        <p>
            Address:
            <br>
            200 Hope Avenue, Salt Lake City, Utah 84115.
            <br>
            Phone: (801) 359-0990
        </p>
    </div>
</template>


